#ifndef DEALTHREAD_H
#define DEALTHREAD_H
#include <QThread>
#include <QPlainTextEdit>
#include <QListWidget>
#include <QProgressBar>
//独立的处理进程
class DealThread : public QThread
{
    Q_OBJECT
public:
    DealThread();
    void set(QListWidget * list,QListWidget * dlglist,int threadbegin,int threadend);//主界面list,对话框list,以及输出框List
protected:
    void run();
private:
    void convert(const QString &path,int count);
    void begintask();
    QString checkisuffix(const QString &str);
    QPixmap pix;
    QImage img;
    QListWidget * dlgList;
    QListWidget * mainList;
    double width;
    double height;

    int begin;//分配的任务开始
    int end;//分配的任务结束部分


public slots:
    void widthchanged(double widthR);
    void heightchanged(double heightR);

signals:
    void progress(int);//进度条变化
    void data(QString);

};

#endif // DEALTHREAD_H
