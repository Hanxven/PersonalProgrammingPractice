#include "threaddeal.h"
#include <QThread>

ThreadDeal::ThreadDeal(QObject *parent) : QThread(parent)
{

}
