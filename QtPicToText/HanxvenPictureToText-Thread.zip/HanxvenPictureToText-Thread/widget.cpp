#include "widget.h"
#include "ui_widget.h"
#include <QFileDialog>
#include <QPixmap>
#include <QImage>
#include <QListWidget>
#include <QListWidgetItem>
#include <QFile>
#include <QMessageBox>
#include "set.h"
#include "aboutdlg.h"
#include "dealthread.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    //ProgramCreatedByHanxven 2020/04/08
    inithis();
}

Widget::~Widget()
{
    delete ui;
}



void Widget::on_btnSet_clicked()
{

    setdlg->show();
}

void Widget::on_btnAddFiles_clicked()
{
    //选择文件夹
    paths = QFileDialog::getOpenFileNames(this,"打开一个或多个文件","","图片文件(*.jpg *.png)");

    if(paths.isEmpty())
        return;


    ui->list->addItems(paths);
    ui->list->setCurrentRow(ui->list->count()-1);

}

void Widget::on_btnDelete_clicked()
{
    if(ui->list->count() == 0)
    {
        QMessageBox::information(this,"提示","没有项目可供删除");
        return;
    }
    QListWidgetItem * itm;
    itm = ui->list->takeItem(ui->list->currentRow());
    delete itm;
    ui->lab->setText(QString::asprintf("文件列表:第%d/%d个文件",ui->list->currentRow() + 1,ui->list->count()));
}

void Widget::on_btnBegin_clicked()
{

      if(ui->list->count() == 0)
      {
          QMessageBox::information(this,"注意","没有项目可供转换");
          return;
      }

      ui->doubleSpinBox->setDisabled(1);
      ui->doubleSpinBox_2->setDisabled(1);
      ui->btnBegin->setDisabled(1);
      ui->btnDelete->setDisabled(1);
      ui->btnAddFiles->setDisabled(1);
      ui->pushButton->setDisabled(1);
      ui->btnSet->setDisabled(1);

      threadP[0].start();

}

//初始化主进程
void Widget::inithis()
{

    ui->doubleSpinBox->setPrefix("宽 ");
    ui->doubleSpinBox_2->setPrefix("高 ");
    ui->lab->setText("添加项目以开始转换");
    setdlg = new set(this);//创建一个对话框对象
    dlglist = setdlg->returnpointer();//接受指针返回
    dlglist->setCurrentRow(0);


    void (QDoubleSpinBox::*pt)(double) = &QDoubleSpinBox::valueChanged;

    connect(&threadP[0],&DealThread::finished,this,&Widget::finishedtask);//检测任务完成度
    connect(&threadP[0],&DealThread::progress,this,&Widget::on_statusBar_valueChanged);//进度条更新
    connect(&threadP[0],&DealThread::data,this,&Widget::setText);//文本内容传输
    connect(ui->doubleSpinBox,pt,&threadP[0],&DealThread::widthchanged);
    connect(ui->doubleSpinBox_2,pt,&threadP[0],&DealThread::heightchanged);
    threadP[0].set(ui->list,dlglist,0,0);


}




void Widget::on_list_currentRowChanged(int currentRow)
{
    ui->lab->setText(QString::asprintf("文件列表:第%d/%d个文件",currentRow + 1,ui->list->count()));
}



void Widget::on_pushButton_clicked()
{
    //删除全部节点
    if(ui->list->count() == 0)
    {
        QMessageBox::information(this,"提示","没有任何项目可供删除");
        return;
    }

    if(QMessageBox::question(this,"确认","即将删除所有条目") == QMessageBox::Yes)
        ui->list->clear();
    else
        return;
    ui->lab->setText("添加文件以开始转换");
}



void Widget::on_btnAbout_clicked()
{
    AboutDlg * dlg = new AboutDlg(this);
    dlg->exec();
}

void Widget::finishedtask()
{//任务完成，恢复按钮的使用
    ui->doubleSpinBox->setEnabled(1);
    ui->doubleSpinBox_2->setEnabled(1);
    ui->btnBegin->setEnabled(1);
    ui->btnDelete->setEnabled(1);
    ui->btnAddFiles->setEnabled(1);
    ui->pushButton->setEnabled(1);
    ui->btnSet->setEnabled(1);
}

void Widget::on_statusBar_valueChanged(int value)
{
    ui->statusBar->setValue(value);
}

void Widget::setText(const QString & str)
{
    ui->statusText->appendPlainText(str);
}


