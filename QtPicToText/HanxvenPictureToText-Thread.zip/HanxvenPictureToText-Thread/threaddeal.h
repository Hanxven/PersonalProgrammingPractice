#ifndef THREADDEAL_H
#define THREADDEAL_H

#include <QObject>

class ThreadDeal : public QObject
{
    Q_OBJECT
public:
    explicit ThreadDeal(QObject *parent = nullptr);

signals:

};

#endif // THREADDEAL_H
