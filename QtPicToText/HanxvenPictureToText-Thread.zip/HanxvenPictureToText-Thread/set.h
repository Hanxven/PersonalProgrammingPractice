#ifndef SET_H
#define SET_H

#include <QDialog>
#include <QListWidgetItem>
namespace Ui {
class set;
}

class set : public QDialog
{
    Q_OBJECT

public:
    explicit set(QWidget *parent = nullptr);

    QStringList setchars(QStringList & list);//处理函数,接受一个字符串列表来进行计算

    void init();//初始化函数
    QListWidget* returnpointer();
    ~set();

private slots:
    void on_rb2_clicked();

    void on_rb4_clicked();

    void on_rb8_clicked();

    void on_rb16_clicked();

    void on_rb32_clicked();

    void on_rb64_clicked();

    void on_rb128_clicked();

    void on_rb256_clicked();

    void on_btnOK_clicked();


    void on_btnset_clicked();

    void on_listW_itemDoubleClicked(QListWidgetItem *item);

    void on_checkBox_stateChanged(int arg1);

private:
    Ui::set *ui;
    QStringList list; //创建初始字符串列表
    int sep;
    void dispatch();
    void fillspace();


};

#endif // SET_H
