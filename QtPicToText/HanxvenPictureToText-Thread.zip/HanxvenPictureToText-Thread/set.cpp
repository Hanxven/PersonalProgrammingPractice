#include "set.h"
#include "ui_set.h"
#include "widget.h"
#include <QInputDialog>
#include <QListWidget>
#include <QMessageBox>
//本窗口用于具体设置颜色梯度的
set::set(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::set)
{
    ui->setupUi(this);
    setWindowFlags(Qt::WindowCloseButtonHint | Qt::Dialog);//无问号显示
    init();


}

set::~set()
{
    delete ui;
}

void set::init()
{
    this->setModal(1);
    sep = 8;//默认为8
    QListWidgetItem * item;
    //应该有2 4 8 16 32 64 128 256种设置方式


    for(int i = 0 ; i < sep ; i++)
    {
        item = new QListWidgetItem;
        item->setData(Qt::UserRole,QString("%1").arg(i));
        item->setText(QString("颜色%1-%3: %4").arg(i*(256/sep),3,10,QLatin1Char('0')).arg((i+1)*(256/sep)-1,3,10,QLatin1Char('0')).arg(i));
        ui->listW->addItem(item);
    }
    fillspace();
    ui->checkBox->setCheckState(Qt::Checked);
}

void set::on_rb2_clicked()
{
    sep = 2;
    dispatch();
}

void set::on_rb4_clicked()
{
    sep = 4;
    dispatch();
}

void set::on_rb8_clicked()
{
    sep = 8;
    dispatch();
}

void set::on_rb16_clicked()
{
    sep = 16;
    dispatch();
    fillspace();
}



void set::on_rb32_clicked()
{
    sep = 32;
    dispatch();
    fillspace();
}

void set::on_rb64_clicked()
{
    sep = 64;
    dispatch();
    fillspace();
}

void set::on_rb128_clicked()
{
    sep = 128;
    dispatch();
    fillspace();
}

void set::on_rb256_clicked()
{
    sep = 256;
    dispatch();
    fillspace();
}

void set::on_btnOK_clicked()
{
    fillspace();
    QMessageBox::information(this,"补齐","已经补全空格,文字长度已对齐");
}



void set::dispatch()
{
    //这个函数将会将树表种内容分割
    ui->listW->clear();//根据QtAss说了,调用此函数删除所有(永久)
    QListWidgetItem * item;

    for(int i = 0 ; i < sep ; i++)
    {
        item = new QListWidgetItem;
        item->setData(Qt::UserRole,QString("%1").arg(i));
        item->setText(QString("颜色%1-%3: %4").arg(i*(256/sep),3,10,QLatin1Char('0')).arg((i+1)*(256/sep)-1,3,10,QLatin1Char('0')).arg(i));
        ui->listW->addItem(item);
    }

}

void set::on_btnset_clicked()
{
    if(ui->listW->currentRow() == -1)
    {
        QMessageBox::information(this,"注意","没有选定修改对象");
        return;
    }
    QList<QListWidgetItem*> items = ui->listW->selectedItems();
    QString str;
    int c = ui->listW->currentRow();
    int r;
    str = QInputDialog::getText(this,"更改项目","为当前条目设置字符串",QLineEdit::Normal,QVariant(ui->listW->item(c)->data(Qt::UserRole)).toString(),nullptr,Qt::Dialog|Qt::WindowCloseButtonHint);
    if(str.isEmpty())
        return;
    for(int i = 0 ; i <items.size() ; i++)
    {
        r = ui->listW->row(items[i]);
        items[i]->setData(Qt::UserRole,str);
        items[i]->setText(QString("颜色%1-%2: %3").arg(r*(256/sep),3,10,QLatin1Char('0')).arg((r+1)*(256/sep)-1,3,10,QLatin1Char('0')).arg(str));
    }

    if(ui->checkBox->isChecked())
        fillspace();
}

void set::on_listW_itemDoubleClicked(QListWidgetItem *item)
{
    Q_UNUSED(item);
    on_btnset_clicked();
}

QListWidget* set::returnpointer()
{
    return ui->listW;//返回主要的指针
}


void set::on_checkBox_stateChanged(int arg1)
{
    if(arg1 == Qt::Checked)
        fillspace();
}

void set::fillspace()
{
    QString str;
    for(int i = 0 ; i < ui->listW->count() ; i++)
    {
        str = QVariant(ui->listW->item(i)->data(Qt::UserRole)).toString();
        str = str.trimmed();
        ui->listW->item(i)->setData(Qt::UserRole,str);
    }


    //补空格设定
    int len;
    int maxLen = QVariant(ui->listW->item(0)->data(Qt::UserRole)).toString().toLocal8Bit().length();
    //获取当前值
    //获取最大值
    for(int i = 0 ; i < ui->listW->count() ; i++)
    {
        len = QVariant(ui->listW->item(i)->data(Qt::UserRole)).toString().toLocal8Bit().length();
        if(len > maxLen)
            maxLen = len;
    }

    //依次填充空格，len变量将用于保存填充数空格
    for(int i = 0 ; i < ui->listW->count() ; i++)
    {
        len = maxLen - QVariant(ui->listW->item(i)->data(Qt::UserRole)).toString().toLocal8Bit().length();
        str = QVariant(ui->listW->item(i)->data(Qt::UserRole)).toString();
        for(int j = 0 ; j < len ; j++)
            str.append(' ');
        ui->listW->item(i)->setData(Qt::UserRole,str);
        ui->listW->item(i)->setText(QString("颜色%1-%2: %3").arg(i*(256/sep),3,10,QLatin1Char('0')).arg((i+1)*(256/sep)-1,3,10,QLatin1Char('0')).arg(str));

    }
}
