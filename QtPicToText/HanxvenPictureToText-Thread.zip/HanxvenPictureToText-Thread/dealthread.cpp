#include "dealthread.h"
#include <QDir>
#include <QPixmap>
#include <QImage>

#include <QFile>
#include <QFileDialog>

DealThread::DealThread()
{
}

void DealThread::set(QListWidget * list,QListWidget * dlglist,int threadbegin,int threadend)
{
    height = 1.0;
    width = 1.0;
    dlgList = dlglist;//对话框list
    mainList = list;//主界

}



void DealThread::run()
{
    //这里执行耗时动作。
    begintask();
    quit();
}

void DealThread::convert(const QString &path,int count)
{

    QFile file(QString("result/") + QString::asprintf("%d.txt",count));
    if(!file.open(QIODevice::WriteOnly))
    {
        emit data(QString("文件:") + path + QString("-尝试写入文件出现问题"));
        return;
    }



    if(QString::compare("jpg",checkisuffix(path),Qt::CaseInsensitive) && QString::compare("png",checkisuffix(path),Qt::CaseInsensitive))
    {
        file.write("不支持的文件格式无法进行转换");
        emit data(QString("文件:") + path + QString("-不支持的文件格式"));
        file.close();
        return;
    }

    emit data(QString("开始转换:") + path + QString::asprintf("-文件:%d",count));

    pix.load(path);
    pix = pix.scaled(pix.height() * width,pix.height() * height);
    img = pix.toImage();


    //图片去色
    for (int i = 0; i < img.width(); i++)
    {
        for (int j= 0; j < img.height(); j++)
        {
            QRgb color = img.pixel(i, j);
            int gray = qGray(color);
            img.setPixel(i, j, qRgba(gray, gray, gray, qAlpha(color)));
        }
    }



    int listcount = dlgList->count();//dlg内部表的数量
    int color; //当前的颜色

    for(int i = 0 ; i < img.height() ; i++)
    {
        for(int j = 0 ; j < img.width() ; j++)
        {
            color = QColor(img.pixel(j,i)).red();//获取当前的颜色值
            for(int z = 0 ; z < listcount ; z++)
            {
                if(color >= z*(256/listcount) && color <= (z+1)*(256/listcount)-1)//位于当前位列
                {
                    QByteArray str = QVariant(dlgList->item(z)->data(Qt::UserRole)).toByteArray();
                    file.write(str);
                }
            }
        }
        file.write("\r\n");
    }

    file.close();
}

void DealThread::begintask()
{
    //创建文件夹
    int prog = 0;
    QDir dir;
    bool suc = true;
    if (!dir.exists("result"))
        dir.mkpath("result");

    if(!suc)
    {
        emit data("--目录创建失败，程序被迫中止--");
        quit();
    }

    emit data(QString("设定比例:%1,%2,共%3文件:").arg(width).arg(height).arg(mainList->count()));

    for(int i = 0 ; i < mainList->count() ; i++)
    {
        convert(mainList->item(i)->text(),i);
        prog = double(i+1) / mainList->count() * 100;
        emit progress(prog);
    }

    emit data("--所有任务完成--");
}


QString DealThread::checkisuffix(const QString &str)
{
    //返回扩展名
    int i = str.length();
    int j = str.lastIndexOf(".");
    return str.right(i-j-1);
}


void DealThread::widthchanged(double widthR)
{
    width = widthR;
}

void DealThread::heightchanged(double heightR)
{
    height = heightR;
}

