#include "aboutdlg.h"
#include "ui_aboutdlg.h"
#include <QMessageBox>
#include <QFile>
#include <widget.h>
AboutDlg::AboutDlg(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AboutDlg)
{
    ui->setupUi(this);
    setWindowFlags(Qt::WindowCloseButtonHint | Qt::Dialog);
    setAttribute(Qt::WA_DeleteOnClose);
    setWindowTitle("关于本程序-HanxvenPicText");

}

AboutDlg::~AboutDlg()
{
    delete ui;
}

